<?php 

namespace DAO;

class Area extends Database {

    const TABLE = 'area';
    protected static $oInstance;
    

   
}
