<?php 

namespace DAO;

class Gravidade extends Database {

    const TABLE = 'config.gravidade';
    protected static $oInstance;
}
