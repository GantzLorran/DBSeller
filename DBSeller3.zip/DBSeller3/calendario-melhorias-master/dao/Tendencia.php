<?php 

namespace DAO;

class Tendencia extends Database {

    const TABLE = 'config.tendencia';
    protected static $oInstance;
}
