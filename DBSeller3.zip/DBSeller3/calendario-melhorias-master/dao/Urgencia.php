<?php 

namespace DAO;

class Urgencia extends Database {

    const TABLE = 'config.urgencia';
    protected static $oInstance;
}
