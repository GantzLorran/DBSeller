<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="../assets\css/pageerrorarguments.css" />
    <script src="../js/backPages.js"></script>
    <title>Acesso Negado</title>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Acesso negado !</h1>
                <div class="mt-5 mb-5">
                    <h2>Erro 403</h2>
                    <div class="mt-3">
                        <h5>Talvez você esteja tentando acessar uma página diretamente, por favor utilize a navegação
                            nativa do sistema.</h5>
                    </div>
                </div>
                <button class="btn btn-outline-danger" onClick="voltar()">Voltar ao início</button>
            </div>
        </div>
    </div>
</body>

</html>