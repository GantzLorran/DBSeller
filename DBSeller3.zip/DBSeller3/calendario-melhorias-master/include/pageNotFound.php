<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="../assets\css/pagenotfound.css" />
    <script src="../js/backPages.js"></script>
    <title>Página não encontrada - 404</title>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Ops.. Algo deu errado !</h1>
                <div class="mt-5 mb-5">
                    <h2>Erro 404</h2>
                    <div class="mt-3">
                        <h5>A página que você está procurando não existe.</h5>
                    </div>
                </div>
                <button class="btn btn-outline-warning" onClick="voltar()">Voltar ao início</button>
            </div>
        </div>
    </div>
</body>

</html>