<?php

error_reporting(E_ALL);
ini_set('display_errors', 'on');

if(!file_exists('vendor/autoload.php')) {
    die('Instale as dependencias');
}

require_once 'vendor/autoload.php';

/**
 * IF que verifica se o parâmetro GET está vazio,
 * Caso esteja, redireciona a página para 'inicio'.
 * 
 * Caso contrário, exibe a página de "ERRO 404" e,
 * termina a execução, ou verifica e exibe a mens-
 * agem de "ACESSO NEGADO".
 *
 */

if(empty($_GET)) {
    header('Location: ?path=inicio');
}
else{
    if(!isset($_GET["path"])){
        require_once __DIR__ . '/include/pageNotFound.php';
        exit;
    }
    else{

        //Variável que irá pegar o valor passado por parâmetro
        $path = $_GET['path'];

        //Verifica se o parâmetro está correto para exibir a página
        if(($path == 'inicio') || ($path == 'agenda')) {
            require_once 'views/home.php';
            require_once ('views/'. $_GET['path'] . '.php');
            exit;
        }
        else{
            require_once __DIR__ . '/include/pageErrorArguments.php';
            exit;
        }
    }
  }

?>