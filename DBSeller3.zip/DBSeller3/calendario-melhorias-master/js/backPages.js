function voltar() {
    window.location.href = "../index.php"
}
